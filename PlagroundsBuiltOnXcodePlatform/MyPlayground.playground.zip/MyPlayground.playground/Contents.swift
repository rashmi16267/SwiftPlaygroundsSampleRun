import UIKit
import PlaygroundSupport

var str = "play"

let color = UIColor (red: 1 , green: 1 , blue: 0 , alpha: 0 )

let view = UIView()

view.frame = CGRect (x: 0 ,y: 0 ,width: 500 ,height: 100 )

let label = UILabel (frame: CGRect (x: 5 , y: 5 , width: 50 , height: 20 ))

label.text = str

view.addSubview(label)

PlaygroundPage.current.liveView =  view
     
