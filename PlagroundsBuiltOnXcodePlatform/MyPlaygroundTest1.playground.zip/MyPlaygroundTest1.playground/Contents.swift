
import SwiftUI
import PlaygroundSupport
import UIKit

struct ContentView: View {
    @State var count: Int = 0
    var body: some View {
        Stepper(value: $count, in:(0...100)) {
            Text("count : \(count)")
        }
    }
}
let preview = ContentView()
    .preferredColorScheme(.dark)
    .background(Color.black)
let vc = UIHostingController(rootView:preview)
PlaygroundPage.current.liveView = vc
