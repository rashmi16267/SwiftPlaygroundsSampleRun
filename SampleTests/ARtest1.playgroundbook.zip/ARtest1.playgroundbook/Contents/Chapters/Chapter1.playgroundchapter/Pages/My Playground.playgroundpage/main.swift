import PlaygroundSupport
import RealityKit
import UIKit

let arscene = ARView(frame: CGRect(),cameraMode: .ar, automaticallyConfigureSession: true)

let sphere = MeshResource.generateSphere(radius: 0.2)

let sphereEntity = ModelEntity(mesh: sphere)

let planeAnchor = AnchorEntity(plane: .horizontal)

let sphereMaterial = SimpleMaterial(color: .blue, isMetallic: true)

arscene.scene.addAnchor(planeAnchor)

planeAnchor.addChild(sphereEntity)

PlaygroundPage.current.setLiveView(arscene)
