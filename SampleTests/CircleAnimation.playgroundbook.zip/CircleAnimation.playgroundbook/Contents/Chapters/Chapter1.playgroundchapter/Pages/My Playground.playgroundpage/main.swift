
import SwiftUI
import PlaygroundSupport

struct Preview: View {
    @State var show = false
    var body : some View {
        Circle()
            .fill(show ? Color.yellow : Color.green)
            .onTapGesture {
                withAnimation(.easeOut){
                    show.toggle()
                }
            }
        Text("Tap on circle")
    }
}

PlaygroundPage.current.setLiveView(Preview())
